import React, { useState } from 'react';
import { useAuth } from '../../hooks/useAuth';
import { User } from 'lucide-react';

export const LoginForm: React.FC = () => {
  const { signInDemo } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleDemoLogin = async () => {
    try {
      console.log('Demo button clicked');
      setLoading(true);
      setError('');
      
      const { error: loginError } = await signInDemo();
      
      if (loginError) {
        setError(loginError.message);
      }
    } catch (err) {
      console.error('Login error:', err);
      setError('ログインに失敗しました。');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <div className="mx-auto h-16 w-16 flex items-center justify-center rounded-full bg-blue-600">
            <User className="h-8 w-8 text-white" />
          </div>
          <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
            業務報告システム
          </h2>
          <p className="mt-2 text-center text-sm text-gray-600">
            Restaurant Business Report System
          </p>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-sm text-red-600">{error}</p>
          </div>
        )}

        <div className="space-y-4">
          <button
            onClick={handleDemoLogin}
            disabled={loading}
            className="group relative w-full flex justify-center py-4 px-4 border border-transparent text-lg font-medium rounded-lg text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:bg-green-300 disabled:cursor-not-allowed transition-colors"
          >
            {loading ? (
              <div className="flex items-center">
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                ログイン中...
              </div>
            ) : (
              <>🚀 デモユーザーでログイン</>
            )}
          </button>
          
          <p className="text-center text-sm text-gray-500">
            すべての機能をデモモードでお試しいただけます
          </p>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <h3 className="text-sm font-medium text-blue-800 mb-2">デモモード機能</h3>
          <ul className="text-xs text-blue-700 space-y-1">
            <li>• ダッシュボード表示</li>
            <li>• 日次報告作成・一覧</li>
            <li>• 売上・経費チャート</li>
            <li>• AIチャット機能</li>
            <li>• 店舗管理</li>
          </ul>
        </div>
      </div>
    </div>
  );
};