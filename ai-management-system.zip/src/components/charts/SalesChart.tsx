import React from 'react'
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine
} from 'recharts'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { formatCurrency, formatDate } from '@/lib/format'
import { DailyReportData } from '@/types'
import { DailyExpenseReference } from '@/hooks/useExpenseBaseline'

interface SalesChartProps {
  reports: DailyReportData[]
  period: 'daily' | 'weekly' | 'monthly'
  onPeriodChange?: (period: 'daily' | 'weekly' | 'monthly') => void
  targetSales?: number
  className?: string
  /** 表示するデータ点の最大数（例：月次=12, 週次=26, 日次=30 など） */
  maxPoints?: number
  onDataPointClick?: (period: string) => void
  expenseBaseline?: DailyExpenseReference
}

export const SalesChart: React.FC<SalesChartProps> = ({
  reports,
  period,
  onPeriodChange,
  targetSales,
  className,
  maxPoints,
  onDataPointClick,
  expenseBaseline
}) => {
  // Process data for chart
  const chartData = React.useMemo(() => {
    const groupedData = new Map<string, {
      date: string
      sales: number
      profit: number
      purchase: number
      count: number
    }>()

    reports.forEach(report => {
      const date = new Date(report.date)
      let key: string

      switch (period) {
        case 'daily':
          key = report.date
          break
        case 'weekly':
          const weekStart = new Date(date)
          const dow = (date.getDay() + 6) % 7 // 月曜=0
          weekStart.setDate(date.getDate() - dow)
          key = weekStart.toISOString().split('T')[0]
          break
        case 'monthly':
          key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`
          break
      }

      if (!groupedData.has(key)) {
        groupedData.set(key, { date: key, sales: 0, profit: 0, purchase: 0, count: 0 })
      }

      const data = groupedData.get(key)!

      data.sales += report.sales
      data.purchase += report.purchase
      data.count += 1
    })

    // 参考経費を使用して営業利益を計算
    const sorted = Array.from(groupedData.values()).map(data => {
      let otherExpenses = 0

      // 参考経費が提供されている場合
      if (expenseBaseline && expenseBaseline.sumOther > 0) {
        // 日次の場合: データポイントの日数分の参考経費
        otherExpenses = expenseBaseline.sumOther * data.count
      }

      // 営業利益 = 売上 - 仕入 - その他経費
      const profit = data.sales - data.purchase - otherExpenses

      return {
        ...data,
        profit
      }
    }).sort((a, b) => a.date.localeCompare(b.date))

    const limit = maxPoints ?? (period === 'monthly' ? 12 : period === 'weekly' ? 26 : 30)
    return sorted.slice(-limit)
  }, [reports, period, expenseBaseline])

  const formatXAxisLabel = (dateStr: string) => {
    const date = new Date(dateStr)
    switch (period) {
      case 'daily':
        return date.toLocaleDateString('ja-JP', { month: 'short', day: 'numeric' })
      case 'weekly':
        return `${date.toLocaleDateString('ja-JP', { month: 'short', day: 'numeric' })}週`
      case 'monthly':
        return date.toLocaleDateString('ja-JP', { year: '2-digit', month: 'short' })
      default:
        return dateStr
    }
  }

  return (
    <Card className={className}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">
            売上推移
          </CardTitle>
          {onPeriodChange && (
            <Tabs value={period} onValueChange={onPeriodChange as any}>
              <TabsList>
                <TabsTrigger value="daily">日次</TabsTrigger>
                <TabsTrigger value="weekly">週次</TabsTrigger>
                <TabsTrigger value="monthly">月次</TabsTrigger>
              </TabsList>
            </Tabs>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto -mx-2 px-2">
          <div className="min-w-[500px]">
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="salesGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="profitGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis
                  dataKey="date"
                  tickFormatter={formatXAxisLabel}
                  className="text-muted-foreground text-xs"
                  angle={-45}
                  textAnchor="end"
                  height={60}
                  interval={0}
                />
                <YAxis
                  tickFormatter={(value) => `¥${(value / 10000).toFixed(0)}万`}
                  className="text-muted-foreground text-xs"
                />
                <Tooltip
                  formatter={(value: number, name: string) => [
                    formatCurrency(value),
                    name === 'sales' ? '売上' : '営業利益'
                  ]}
                  labelFormatter={formatXAxisLabel}
                  contentStyle={{
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '6px'
                  }}
                />
                {targetSales && (
                  <ReferenceLine
                    y={targetSales}
                    stroke="hsl(var(--ring))"
                    strokeDasharray="4 4"
                    label="目標"
                  />
                )}
                <Area
                  type="monotone"
                  dataKey="sales"
                  stroke="#6366f1"
                  fill="url(#salesGradient)"
                  strokeWidth={2}
                  onClick={(data: any) => {
                    if (onDataPointClick && data?.payload) {
                      onDataPointClick(data.payload.date)
                    }
                  }}
                  style={{ cursor: onDataPointClick ? 'pointer' : 'default' }}
                />
                <Area
                  type="monotone"
                  dataKey="profit"
                  stroke="#10b981"
                  fill="url(#profitGradient)"
                  strokeWidth={2}
                  onClick={(data: any) => {
                    if (onDataPointClick && data?.payload) {
                      onDataPointClick(data.payload.date)
                    }
                  }}
                  style={{ cursor: onDataPointClick ? 'pointer' : 'default' }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}