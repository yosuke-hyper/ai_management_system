import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Mail, Lock, User, CircleAlert as AlertCircle, Building } from 'lucide-react'
import { useAuth } from '@/contexts/AuthContext'

export const LoginForm: React.FC = () => {
  const navigate = useNavigate()
  const { signUp, signIn, loading: authLoading } = useAuth()

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    organizationName: ''
  })
  const [isSignUp, setIsSignUp] = useState(false)
  const [localSubmitting, setLocalSubmitting] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  const submitting = authLoading || localSubmitting

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }))
    setError('')
    setSuccess('')
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    console.log('🟦 LoginForm: フォーム送信開始')
    setError('')
    setSuccess('')
    setLocalSubmitting(true)

    try {
      if (isSignUp) {
        // サインアップ
        if (!formData.name || !formData.email || !formData.password || !formData.organizationName) {
          setError('すべての項目を入力してください')
          setLocalSubmitting(false)
          return
        }

        if (formData.password.length < 8) {
          setError('パスワードは8文字以上で入力してください')
          setLocalSubmitting(false)
          return
        }

        console.log('🟦 LoginForm: サインアップ開始')
        const { data, error } = await signUp(
          formData.email,
          formData.password,
          formData.name,
          'staff',
          formData.organizationName
        )

        if (error) {
          console.error('❌ LoginForm: サインアップエラー', error)
          setError(error.message)
          setLocalSubmitting(false)
          return
        }

        if (data) {
          console.log('✅ LoginForm: サインアップ成功')
          setSuccess('アカウントと組織が作成されました。ログインしてください。')
          setIsSignUp(false)
          setFormData({ name: '', email: formData.email, password: '', organizationName: '' })
          setLocalSubmitting(false)
        }
      } else {
        // サインイン
        if (!formData.email || !formData.password) {
          setError('メールアドレスとパスワードを入力してください')
          setLocalSubmitting(false)
          return
        }

        console.log('🟦 LoginForm: サインイン開始', formData.email)
        const { data, error } = await signIn(formData.email, formData.password)
        console.log('🟦 LoginForm: サインイン完了', { data, error })

        if (error) {
          console.error('❌ LoginForm: サインインエラー', error)
          setError(error.message || 'ログインに失敗しました')
          setLocalSubmitting(false)
          return
        }

        if (data) {
          console.log('✅ LoginForm: サインイン成功、ダッシュボードへ遷移')
          navigate('/dashboard/daily', { replace: true })
        }
      }
    } catch (err) {
      console.error('❌ LoginForm: 予期しないエラー', err)
      setError('予期しないエラーが発生しました')
      setLocalSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 py-12 px-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="space-y-1 pb-6">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
              <Building className="w-10 h-10 text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold text-center">
            株式会社あさひ
          </CardTitle>
          <p className="text-center text-slate-600 text-sm">
            {isSignUp ? '新規アカウント登録' : '業務管理システム'}
          </p>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {isSignUp && (
              <>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    <Building className="w-4 h-4 inline mr-2" />
                    組織名
                  </label>
                  <input
                    type="text"
                    name="organizationName"
                    value={formData.organizationName}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                    placeholder="株式会社〇〇"
                    disabled={submitting}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-2">
                    <User className="w-4 h-4 inline mr-2" />
                    お名前
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                    placeholder="山田太郎"
                    disabled={submitting}
                  />
                </div>
              </>
            )}

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                <Mail className="w-4 h-4 inline mr-2" />
                メールアドレス
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                placeholder="your-email@example.com"
                disabled={submitting}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                <Lock className="w-4 h-4 inline mr-2" />
                パスワード
              </label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleInputChange}
                className="w-full px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition"
                placeholder="8文字以上"
                disabled={submitting}
              />
            </div>

            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-red-800">{error}</p>
              </div>
            )}

            {success && (
              <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-sm text-green-800">{success}</p>
              </div>
            )}

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white font-medium py-2.5 rounded-lg transition-all shadow-md hover:shadow-lg"
              disabled={submitting}
            >
              {submitting ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></span>
                  処理中...
                </span>
              ) : isSignUp ? (
                'アカウント作成'
              ) : (
                'ログイン'
              )}
            </Button>

            <div className="text-center mt-4">
              <button
                type="button"
                onClick={() => {
                  setIsSignUp(!isSignUp)
                  setError('')
                  setSuccess('')
                }}
                className="text-sm text-blue-600 hover:text-blue-700 hover:underline transition"
                disabled={submitting}
              >
                {isSignUp
                  ? 'すでにアカウントをお持ちの方はこちら'
                  : '新規アカウント登録はこちら'}
              </button>
            </div>
          </form>

          <div className="mt-6 pt-6 border-t border-slate-200">
            <p className="text-xs text-center text-slate-500">
              初回ログイン時は管理者に連絡してアカウントを作成してください
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
