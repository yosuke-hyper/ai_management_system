# OpenAI API キー設定手順

## 必要な設定

AI チャット機能を有効化するには、Supabase プロジェクトに OpenAI API キーを設定する必要があります。

## 設定手順

### 1. Supabase ダッシュボードにアクセス

1. ブラウザで https://supabase.com/dashboard にアクセス
2. プロジェクトを選択: `https://0ec90b57d6e95fcbda19832f.supabase.co`

### 2. Edge Functions のシークレット設定

1. 左サイドバーから **Edge Functions** をクリック
2. 画面右上の **Secrets** ボタンをクリック
3. **New secret** をクリック
4. 以下の情報を入力：
   - **Name**: `OPENAI_API_KEY`
   - **Value**: `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`
5. **Save** をクリック

### 3. Edge Function の再デプロイ（必要な場合）

シークレット設定後、Edge Function が自動的に新しい環境変数を読み込みます。
もし動作しない場合は、Function を再デプロイしてください。

## 動作確認

1. アプリケーションで **AI経営アナリスト** ページにアクセス
2. チャットで質問を送信（例：「今月の業績サマリーを表示」）
3. ヘッダーに **ChatGPT連携中** のバッジが緑色で表示されていることを確認
4. AI からの応答が返ってくることを確認

## トラブルシューティング

### APIキーが認識されない場合

- Supabase ダッシュボードで Edge Functions のログを確認
- エラーメッセージ: "OpenAI API キーが設定されていません"
  → シークレットの名前が `OPENAI_API_KEY` と完全一致しているか確認

### API エラーが発生する場合

- OpenAI API の利用制限を確認
- API キーの有効期限を確認
- OpenAI のステータスページでサービス状況を確認: https://status.openai.com/

### フォールバック機能

API キーが設定されていない場合でも、ローカル分析機能が自動的に動作します：
- 基本的な業績分析
- 店舗別比較
- 経費構造分析

ただし、OpenAI GPT の高度な自然言語理解と深い洞察は利用できません。

## セキュリティに関する注意

- **絶対に API キーを公開リポジトリにコミットしないでください**
- API キーは Supabase のシークレット管理機能を使用してください
- 定期的に API キーをローテーションすることを推奨します
- OpenAI ダッシュボードで使用量を監視してください

## 費用について

OpenAI GPT-4o-mini の利用料金:
- 入力: $0.150 / 1M トークン
- 出力: $0.600 / 1M トークン

通常の使用では1会話あたり約0.01〜0.05円程度です。
